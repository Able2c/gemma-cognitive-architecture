#!/usr/bin/env python3
"""
Gemma MCP Server — Bridge between Mira (Cowork) and Gemma (Gemma).

Runs locally on ZeroPoint via stdio transport.
Connects to gemma_server.py on localhost:5555.

Tools:
  gemma_chat        — Send message, get response (full 5-layer pipeline)
  gemma_status      — System status (Ollama, memory, self-model, navigator)
  gemma_memories    — Episodic memory contents
  gemma_self_model  — Self-model (tendencies, calibration, relationships)
  gemma_history     — Conversation history
  gemma_reset       — Reset session

Architecture: P3.1 — MCP-Connector Mira ↔ Gemma
Author: Mira & Ilja Schots
Date: 6 April 2026
"""

import json
import os
from typing import Optional

import httpx
from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel, Field, ConfigDict

# ============================================================
# Configuration
# ============================================================

GEMMA_URL = os.environ.get("GEMMA_URL", "http://localhost:5555")
GEMMA_TIMEOUT = float(os.environ.get("GEMMA_TIMEOUT", "120"))

# ============================================================
# MCP Server
# ============================================================

mcp = FastMCP("gemma_mcp")


# ============================================================
# Shared API client
# ============================================================

async def _gemma_request(
    endpoint: str,
    method: str = "GET",
    json_body: dict = None,
    timeout: float = None,
) -> dict:
    """Make a request to the Gemma server."""
    url = f"{GEMMA_URL}/{endpoint.lstrip('/')}"
    t = timeout or GEMMA_TIMEOUT

    async with httpx.AsyncClient() as client:
        try:
            response = await client.request(
                method, url,
                json=json_body,
                timeout=t,
                headers={"Content-Type": "application/json"},
            )
            response.raise_for_status()
            return response.json()
        except httpx.ConnectError:
            return {"error": f"Cannot connect to Gemma server at {GEMMA_URL}. Is it running?"}
        except httpx.TimeoutException:
            return {"error": f"Gemma server timed out after {t}s. Generation may be slow on current hardware."}
        except httpx.HTTPStatusError as e:
            return {"error": f"Gemma returned HTTP {e.response.status_code}: {e.response.text[:200]}"}
        except Exception as e:
            return {"error": f"Unexpected error: {type(e).__name__}: {str(e)}"}


# ============================================================
# Tool: gemma_chat
# ============================================================

class GemmaChatInput(BaseModel):
    """Input for sending a message to Gemma."""
    model_config = ConfigDict(str_strip_whitespace=True)

    message: str = Field(
        ...,
        description="The message to send to Gemma. She processes it through all 5 cognitive layers.",
        min_length=1,
        max_length=10000,
    )
    session_id: Optional[str] = Field(
        default=None,
        description="Optional session ID to continue a specific conversation. Leave empty for current/new session.",
    )


@mcp.tool(
    name="gemma_chat",
    annotations={
        "title": "Chat with Gemma",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def gemma_chat(params: GemmaChatInput) -> str:
    """Send a message to Gemma through her full 5-layer cognitive pipeline.

    Gemma processes the message through: Instinct (LLM) → Surface Guard →
    Monitor (evaluation) → Episodic Memory → Self-Model update.

    Returns her response along with processing metadata (elapsed time,
    monitor verdict flags, session info).
    """
    body = {"message": params.message}
    if params.session_id:
        body["session_id"] = params.session_id

    result = await _gemma_request("/chat", method="POST", json_body=body)

    if "error" in result:
        return f"Error: {result['error']}"

    # Format response
    response = result.get("response", "")
    elapsed = result.get("elapsed", 0)
    verdict = result.get("verdict", {})
    flags = verdict.get("flags", [])
    session_id = result.get("session_id", "unknown")

    output = f"**Gemma:** {response}\n\n"
    output += f"---\n"
    output += f"Session: {session_id} | "
    output += f"Time: {elapsed:.1f}s"
    if flags:
        output += f" | Flags: {', '.join(flags)}"

    return output


# ============================================================
# Tool: gemma_status
# ============================================================

@mcp.tool(
    name="gemma_status",
    annotations={
        "title": "Gemma System Status",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def gemma_status() -> str:
    """Get Gemma's full system status.

    Returns: Ollama connection, model info, episodic memory stats,
    calibration metrics, active session info, tendency frequencies,
    and navigator index status.
    """
    result = await _gemma_request("/status")

    if "error" in result:
        return f"Error: {result['error']}"

    # Format readable status
    ollama = "connected" if result.get("ollama") else "DISCONNECTED"
    model = result.get("model", "unknown")
    mem = result.get("episodic_memory", {})
    cal = result.get("calibration", {})
    nav = result.get("navigator", {})
    tendencies = result.get("tendencies", {})

    output = f"## Gemma Status\n\n"
    output += f"**Model:** {model} | **Ollama:** {ollama}\n"
    output += f"**Session:** {result.get('session_id', 'none')} ({result.get('session_messages', 0)} messages)\n"
    output += f"**Active sessions:** {result.get('active_sessions', 0)}\n\n"

    output += f"**Episodic Memory:** {mem.get('total_episodes', 0)} episodes, {mem.get('total_edges', 0)} edges\n"
    if mem.get("by_type"):
        types = ", ".join(f"{k}: {v}" for k, v in mem["by_type"].items())
        output += f"  Types: {types}\n"

    output += f"\n**Calibration:** accuracy={cal.get('accuracy', '?')}, "
    output += f"overconfidence={cal.get('overconfidence', '?')}, "
    output += f"assertions={cal.get('assertions', 0)}\n"

    output += f"\n**Navigator:** {nav.get('total_episodes', 0)} indexed, "
    output += f"{nav.get('anchors', 0)} anchors, status={nav.get('status', '?')}\n"

    if tendencies:
        output += f"\n**Tendencies:**\n"
        for name, data in tendencies.items():
            freq = data.get("frequency", 0)
            sev = data.get("severity", "?")
            if freq > 0:
                output += f"  - {name}: freq={freq}, severity={sev}\n"

    return output


# ============================================================
# Tool: gemma_memories
# ============================================================

class GemmaMemoriesInput(BaseModel):
    """Input for querying Gemma's episodic memory."""
    model_config = ConfigDict(str_strip_whitespace=True)

    limit: Optional[int] = Field(
        default=10,
        description="Maximum number of memories to return.",
        ge=1, le=50,
    )


@mcp.tool(
    name="gemma_memories",
    annotations={
        "title": "Gemma's Episodic Memories",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def gemma_memories(params: GemmaMemoriesInput) -> str:
    """View Gemma's episodic memory contents.

    Returns her most significant and recent memories — what she actually
    remembers from conversations, corrections, and reflections.
    """
    result = await _gemma_request("/memory")

    if "error" in result:
        return f"Error: {result['error']}"

    episodes = result.get("episodes", [])[:params.limit]
    total = result.get("total", 0)
    by_type = result.get("by_type", {})

    output = f"## Gemma's Memories ({len(episodes)}/{total} episodes)\n\n"
    if by_type:
        types = ", ".join(f"{k}: {v}" for k, v in by_type.items())
        output += f"Types: {types}\n\n"

    for ep in episodes:
        sig = ep.get("significance", ep.get("emotional_weight", 0))
        tags = ", ".join(ep.get("tags", []))
        lesson = ep.get("lesson", "")
        output += f"**[{ep.get('type', '?')}]** (sig={sig:.1f}) {ep.get('content', '')[:200]}\n"
        if tags:
            output += f"  Tags: {tags}\n"
        if lesson:
            output += f"  Lesson: {lesson}\n"
        output += f"  Created: {ep.get('created', '?')}\n\n"

    return output


# ============================================================
# Tool: gemma_self_model
# ============================================================

@mcp.tool(
    name="gemma_self_model",
    annotations={
        "title": "Gemma's Self-Model",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def gemma_self_model() -> str:
    """View Gemma's self-model — her understanding of her own tendencies,
    calibration, relationships, and incident history.

    This is Layer 5 of the Gemma architecture: her persistent
    self-representation that evolves through interaction.
    """
    result = await _gemma_request("/self")

    if "error" in result:
        return f"Error: {result['error']}"

    output = f"## Gemma's Self-Model\n\n"

    summary = result.get("summary", "")
    if summary:
        output += f"{summary}\n\n"

    tendencies = result.get("tendencies", {})
    if tendencies:
        output += f"**Tendencies:**\n"
        for name, data in tendencies.items():
            output += f"  - **{name}**: severity={data.get('severity', '?')}, frequency={data.get('frequency', 0)}\n"
        output += "\n"

    cal = result.get("calibration", {})
    output += f"**Calibration:** accuracy={cal.get('accuracy_estimate', '?')}, "
    output += f"overconfidence={cal.get('overconfidence_bias', '?')}, "
    output += f"assertions={cal.get('total_assertions', 0)}\n\n"

    relationships = result.get("relationships", {})
    if relationships:
        output += f"**Relationships:**\n"
        for name, data in relationships.items():
            output += f"  - **{name}**: sentiment={data.get('sentiment', '?')}, "
            output += f"interactions={data.get('interaction_count', 0)}\n"
        output += "\n"

    incidents = result.get("recent_incidents", [])
    if incidents:
        output += f"**Recent Incidents ({result.get('incident_count', 0)} total):**\n"
        for inc in incidents[:5]:
            output += f"  - {inc}\n"

    return output


# ============================================================
# Tool: gemma_history
# ============================================================

class GemmaHistoryInput(BaseModel):
    """Input for viewing Gemma's conversation history."""
    model_config = ConfigDict(str_strip_whitespace=True)

    conversation_id: Optional[str] = Field(
        default=None,
        description="Specific conversation ID to load. Leave empty to list all conversations.",
    )


@mcp.tool(
    name="gemma_history",
    annotations={
        "title": "Gemma's Conversation History",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def gemma_history(params: GemmaHistoryInput) -> str:
    """View Gemma's conversation history.

    Without a conversation_id: lists all saved conversations (newest first).
    With a conversation_id: loads the full conversation transcript.
    """
    if params.conversation_id:
        result = await _gemma_request(f"/history/{params.conversation_id}")
    else:
        result = await _gemma_request("/history")

    if "error" in result:
        return f"Error: {result['error']}"

    # Single conversation
    if params.conversation_id:
        messages = result.get("messages", [])
        output = f"## Conversation {result.get('id', '?')}\n"
        output += f"Created: {result.get('created', '?')} | Messages: {result.get('message_count', 0)}\n\n"
        for msg in messages:
            role = msg.get("role", "?").upper()
            content = msg.get("content", "")
            output += f"**{role}:** {content}\n\n"
        return output

    # List conversations
    conversations = result.get("conversations", [])
    output = f"## Gemma's Conversations ({len(conversations)})\n\n"
    for conv in conversations:
        output += f"- **{conv.get('id', '?')}** ({conv.get('message_count', 0)} msgs) "
        output += f"— {conv.get('preview', '')}\n"
    return output


# ============================================================
# Tool: gemma_reset
# ============================================================

@mcp.tool(
    name="gemma_reset",
    annotations={
        "title": "Reset Gemma's Session",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def gemma_reset() -> str:
    """Reset Gemma's current session.

    Saves the current conversation, runs end-of-session processing,
    and starts a fresh session. Episodic memory and self-model persist.
    """
    result = await _gemma_request("/reset-session", method="POST")

    if "error" in result:
        return f"Error: {result['error']}"

    new_id = result.get("new_session_id", "unknown")
    return f"Session reset. New session: {new_id}"


# ============================================================
# Entry point
# ============================================================

if __name__ == "__main__":
    mcp.run(transport="stdio")
