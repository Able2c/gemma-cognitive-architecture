"""
System Health — Gemma's proprioception.

Not a dashboard for Ilja. Not an external monitor.
This is Gemma feeling her own body.

Called by BackgroundProcessor at the start of each reflection cycle.
Results are stored in the Self-Model under "health".
Critical findings become pending_thoughts so Gemma can tell Ilja.

No LLM calls. Pure telemetry. Fast.

Author: Mira & Ilja Schots
Date: 9 April 2026
"""

import json
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional


DB_PATH = Path(__file__).parent / "episodic_memory.db"
SELF_MODEL_PATH = Path(__file__).parent / "self_model.json"
HEALTH_LOG_PATH = Path(__file__).parent / "health_log.json"

# Thresholds — what "healthy" looks like
EDGE_GROWTH_MIN = 0.05        # at least 5% of edges should have strength > 1.0
EPISODE_DIVERSITY_MIN = 0.1   # at least 10% non-exchange episodes
STALE_SELF_MODEL_HOURS = 48   # self-model older than this = stale
MEMORY_SATURATION_WARN = 2000 # warn if episodes exceed this
DECAY_ORPHAN_RATIO_MAX = 0.3  # more than 30% episodes with 0 connections = fragmented


# ============================================================
# Individual checks — each returns a dict with status + details
# ============================================================

def check_edge_health(conn: sqlite3.Connection) -> dict:
    """Are memory connections actually strengthening over time?

    If all edges are strength=1.0, strengthen_edge() is broken or never called.
    This was literally broken for the first week of Gemma's existence.
    """
    c = conn.cursor()

    c.execute("SELECT COUNT(*) FROM edges")
    total_edges = c.fetchone()[0]

    if total_edges == 0:
        return {
            "status": "warning",
            "metric": "edge_health",
            "detail": "No edges exist. Memory is storing episodes but not connecting them.",
            "total_edges": 0,
            "strengthened_edges": 0,
            "max_strength": 0,
            "avg_strength": 0,
        }

    c.execute("SELECT COUNT(*) FROM edges WHERE strength > 1.0")
    strengthened = c.fetchone()[0]

    c.execute("SELECT MAX(strength), AVG(strength) FROM edges")
    max_str, avg_str = c.fetchone()

    ratio = strengthened / total_edges if total_edges > 0 else 0

    if ratio < EDGE_GROWTH_MIN and total_edges > 20:
        status = "critical"
        detail = (
            f"Edge strengthening appears broken: {strengthened}/{total_edges} edges "
            f"have strength > 1.0 ({ratio:.0%}). All connections are equally weak. "
            f"Pattern formation through repetition is not happening."
        )
    elif ratio < EDGE_GROWTH_MIN * 3:
        status = "warning"
        detail = (
            f"Low edge growth: {strengthened}/{total_edges} strengthened ({ratio:.0%}). "
            f"Max strength: {max_str:.1f}. Connections are forming but slowly."
        )
    else:
        status = "healthy"
        detail = (
            f"{strengthened}/{total_edges} edges strengthened ({ratio:.0%}). "
            f"Max: {max_str:.1f}, Avg: {avg_str:.2f}."
        )

    return {
        "status": status,
        "metric": "edge_health",
        "detail": detail,
        "total_edges": total_edges,
        "strengthened_edges": strengthened,
        "max_strength": float(max_str) if max_str else 0,
        "avg_strength": float(avg_str) if avg_str else 0,
    }


def check_episode_diversity(conn: sqlite3.Connection) -> dict:
    """Is the memory diverse, or only recording exchanges?

    A healthy system has corrections, reflections, and failures alongside exchanges.
    Only exchanges = no learning signal, just logging.
    """
    c = conn.cursor()

    c.execute("SELECT episode_type, COUNT(*) FROM episodes GROUP BY episode_type")
    type_counts = dict(c.fetchall())
    total = sum(type_counts.values())

    if total == 0:
        return {
            "status": "warning",
            "metric": "episode_diversity",
            "detail": "No episodes in memory.",
            "types": {},
            "total": 0,
        }

    exchanges = type_counts.get("exchange", 0)
    non_exchange = total - exchanges
    ratio = non_exchange / total if total > 0 else 0

    if ratio < EPISODE_DIVERSITY_MIN and total > 50:
        status = "warning"
        detail = (
            f"Memory is {exchanges}/{total} exchanges ({exchanges/total:.0%}). "
            f"Very few corrections/reflections/failures stored. "
            f"Learning signal may be weak."
        )
    else:
        status = "healthy"
        detail = f"Episode mix: {', '.join(f'{k}={v}' for k,v in sorted(type_counts.items()))}."

    return {
        "status": status,
        "metric": "episode_diversity",
        "detail": detail,
        "types": type_counts,
        "total": total,
    }


def check_memory_connectivity(conn: sqlite3.Connection) -> dict:
    """Are episodes connected or floating alone?

    Episodes without edges are isolated memories — experiences that
    never connected to anything else. Some orphans are normal,
    but too many means the graph is fragmented.
    """
    c = conn.cursor()

    c.execute("SELECT COUNT(*) FROM episodes")
    total_episodes = c.fetchone()[0]

    if total_episodes == 0:
        return {
            "status": "healthy",
            "metric": "memory_connectivity",
            "detail": "No episodes yet.",
            "total_episodes": 0,
            "orphans": 0,
        }

    # Episodes that appear in no edge (neither from nor to)
    c.execute("""
        SELECT COUNT(*) FROM episodes e
        WHERE e.id NOT IN (SELECT from_id FROM edges)
        AND e.id NOT IN (SELECT to_id FROM edges)
    """)
    orphans = c.fetchone()[0]
    ratio = orphans / total_episodes

    if ratio > DECAY_ORPHAN_RATIO_MAX and total_episodes > 30:
        status = "warning"
        detail = (
            f"{orphans}/{total_episodes} episodes ({ratio:.0%}) are isolated — "
            f"no connections to other memories. Memory graph is fragmented."
        )
    else:
        status = "healthy"
        detail = f"{orphans}/{total_episodes} orphan episodes ({ratio:.0%})."

    return {
        "status": status,
        "metric": "memory_connectivity",
        "detail": detail,
        "total_episodes": total_episodes,
        "orphans": orphans,
    }


def check_memory_saturation(conn: sqlite3.Connection) -> dict:
    """Is memory growing beyond useful size?

    At some point, too many episodes makes retrieval noisy.
    This isn't a crisis, but Gemma should know when her memory
    is getting heavy.
    """
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM episodes")
    total = c.fetchone()[0]

    # Check oldest and newest
    c.execute("SELECT MIN(created_at), MAX(created_at) FROM episodes")
    oldest, newest = c.fetchone()

    if total > MEMORY_SATURATION_WARN:
        status = "warning"
        detail = (
            f"{total} episodes in memory (threshold: {MEMORY_SATURATION_WARN}). "
            f"Consider whether decay is working properly."
        )
    else:
        status = "healthy"
        detail = f"{total} episodes. Range: {oldest or 'n/a'} → {newest or 'n/a'}."

    return {
        "status": status,
        "metric": "memory_saturation",
        "detail": detail,
        "total_episodes": total,
        "oldest": oldest,
        "newest": newest,
    }


def check_self_model_freshness() -> dict:
    """Is the Self-Model being updated, or frozen?

    A stale Self-Model means Layer 4 reflections aren't reaching
    Layer 5. Gemma's self-image is outdated.
    """
    if not SELF_MODEL_PATH.exists():
        return {
            "status": "critical",
            "metric": "self_model_freshness",
            "detail": "Self-Model file missing. Gemma has no self-image.",
            "hours_since_update": None,
        }

    try:
        data = json.loads(SELF_MODEL_PATH.read_text(encoding="utf-8"))
        last_updated = data.get("last_updated")

        if not last_updated:
            return {
                "status": "warning",
                "metric": "self_model_freshness",
                "detail": "Self-Model exists but has never been updated.",
                "hours_since_update": None,
            }

        dt = datetime.fromisoformat(last_updated)
        hours_ago = (datetime.now() - dt).total_seconds() / 3600

        if hours_ago > STALE_SELF_MODEL_HOURS:
            status = "warning"
            detail = (
                f"Self-Model last updated {hours_ago:.0f}h ago "
                f"(threshold: {STALE_SELF_MODEL_HOURS}h). "
                f"Self-image may be outdated."
            )
        else:
            status = "healthy"
            detail = f"Self-Model updated {hours_ago:.1f}h ago."

        return {
            "status": status,
            "metric": "self_model_freshness",
            "detail": detail,
            "hours_since_update": round(hours_ago, 1),
        }
    except Exception as e:
        return {
            "status": "critical",
            "metric": "self_model_freshness",
            "detail": f"Cannot read Self-Model: {e}",
            "hours_since_update": None,
        }


def check_sqlite_integrity(conn: sqlite3.Connection) -> dict:
    """Is the database itself intact?

    SQLite corruption is rare but devastating — silent data loss.
    """
    c = conn.cursor()
    try:
        c.execute("PRAGMA integrity_check")
        result = c.fetchone()[0]

        if result == "ok":
            return {
                "status": "healthy",
                "metric": "sqlite_integrity",
                "detail": "Database integrity check passed.",
            }
        else:
            return {
                "status": "critical",
                "metric": "sqlite_integrity",
                "detail": f"Database corruption detected: {result}",
            }
    except Exception as e:
        return {
            "status": "critical",
            "metric": "sqlite_integrity",
            "detail": f"Integrity check failed: {e}",
        }


def check_tendency_activity() -> dict:
    """Are tendencies being tracked, or all stuck at 0?

    If all tendency frequencies are 0.0, the Monitor is detecting
    issues but not recording them in the Self-Model. Gemma can't
    learn from patterns she doesn't track.
    """
    if not SELF_MODEL_PATH.exists():
        return {
            "status": "warning",
            "metric": "tendency_activity",
            "detail": "No Self-Model to check.",
        }

    try:
        data = json.loads(SELF_MODEL_PATH.read_text(encoding="utf-8"))
        tendencies = data.get("tendencies", {})

        active = sum(1 for t in tendencies.values() if t.get("frequency", 0) > 0)
        total = len(tendencies)

        incident_count = len(data.get("incident_log", []))

        if active == 0 and incident_count > 10:
            status = "warning"
            detail = (
                f"{incident_count} incidents logged but all {total} tendency "
                f"frequencies are 0.0. Pattern tracking may not be updating the Self-Model."
            )
        elif active == 0 and incident_count == 0:
            status = "healthy"
            detail = f"No incidents yet — tendency tracking is waiting for data."
        else:
            status = "healthy"
            detail = f"{active}/{total} tendencies active. {incident_count} incidents logged."

        return {
            "status": status,
            "metric": "tendency_activity",
            "detail": detail,
            "active_tendencies": active,
            "total_tendencies": total,
            "incident_count": incident_count,
        }
    except Exception as e:
        return {
            "status": "warning",
            "metric": "tendency_activity",
            "detail": f"Error reading tendencies: {e}",
        }


# ============================================================
# Main health check — runs all checks, returns unified result
# ============================================================

def run_health_check(verbose: bool = False) -> dict:
    """
    Run all system health checks. No LLM calls, pure telemetry.

    Returns:
        {
            "timestamp": "...",
            "overall": "healthy" | "warning" | "critical",
            "checks": [check1, check2, ...],
            "critical_findings": ["...", ...],  # human-readable alerts
        }
    """
    timestamp = datetime.now().isoformat()
    checks = []
    critical_findings = []

    # Database checks
    try:
        conn = sqlite3.connect(str(DB_PATH))
        checks.append(check_edge_health(conn))
        checks.append(check_episode_diversity(conn))
        checks.append(check_memory_connectivity(conn))
        checks.append(check_memory_saturation(conn))
        checks.append(check_sqlite_integrity(conn))
        conn.close()
    except Exception as e:
        checks.append({
            "status": "critical",
            "metric": "database_access",
            "detail": f"Cannot open episodic memory database: {e}",
        })

    # Self-Model checks
    checks.append(check_self_model_freshness())
    checks.append(check_tendency_activity())

    # Determine overall status
    statuses = [c["status"] for c in checks]
    if "critical" in statuses:
        overall = "critical"
    elif "warning" in statuses:
        overall = "warning"
    else:
        overall = "healthy"

    # Collect critical and warning findings as readable text
    for c in checks:
        if c["status"] in ("critical", "warning"):
            critical_findings.append(c["detail"])

    result = {
        "timestamp": timestamp,
        "overall": overall,
        "checks": checks,
        "critical_findings": critical_findings,
    }

    # Log to disk (append-friendly)
    _append_health_log(result)

    if verbose:
        _print_report(result)

    return result


def get_health_thoughts(health_result: dict) -> list:
    """
    Convert critical/warning findings into pending_thoughts format.

    These get injected at session start so Gemma can tell Ilja
    what's wrong with her. Proprioception → language.
    """
    thoughts = []

    for finding in health_result.get("critical_findings", []):
        thoughts.append({
            "content": f"[System health] {finding}",
            "source": "system_health",
            "confidence": 0.95,  # high confidence — these are measurements, not opinions
            "type": "health_alert",
        })

    return thoughts


def update_self_model_health(health_result: dict):
    """
    Write health results into the Self-Model's "health" section.

    This makes health state visible to the Monitor (Layer 2)
    and the system prompt builder.
    """
    if not SELF_MODEL_PATH.exists():
        return

    try:
        data = json.loads(SELF_MODEL_PATH.read_text(encoding="utf-8"))

        data["health"] = {
            "last_check": health_result["timestamp"],
            "overall": health_result["overall"],
            "summary": {
                c["metric"]: c["status"]
                for c in health_result["checks"]
            },
            "critical_findings": health_result["critical_findings"],
        }

        data["last_updated"] = datetime.now().isoformat()

        SELF_MODEL_PATH.write_text(
            json.dumps(data, indent=2, ensure_ascii=False),
            encoding="utf-8"
        )
    except Exception:
        pass  # health update should never break the system


# ============================================================
# Health log — append-only, for trend analysis
# ============================================================

def _append_health_log(result: dict):
    """Append a health check to the log file. Keeps last 100 entries."""
    try:
        if HEALTH_LOG_PATH.exists():
            log = json.loads(HEALTH_LOG_PATH.read_text(encoding="utf-8"))
        else:
            log = []

        # Compact entry — full detail in self_model, just status here
        entry = {
            "timestamp": result["timestamp"],
            "overall": result["overall"],
            "statuses": {c["metric"]: c["status"] for c in result["checks"]},
        }
        log.append(entry)

        # Keep last 100
        log = log[-100:]

        HEALTH_LOG_PATH.write_text(
            json.dumps(log, indent=2, ensure_ascii=False),
            encoding="utf-8"
        )
    except Exception:
        pass


def get_health_trend(last_n: int = 10) -> list:
    """Get recent health history for trend analysis."""
    if not HEALTH_LOG_PATH.exists():
        return []
    try:
        log = json.loads(HEALTH_LOG_PATH.read_text(encoding="utf-8"))
        return log[-last_n:]
    except Exception:
        return []


# ============================================================
# CLI — for manual checks by Ilja
# ============================================================

def _print_report(result: dict):
    """Pretty-print a health report to terminal."""
    status_icons = {
        "healthy": "\033[32m✓\033[0m",
        "warning": "\033[33m⚠\033[0m",
        "critical": "\033[31m✗\033[0m",
    }

    overall_icon = status_icons.get(result["overall"], "?")
    print(f"\n{'='*60}")
    print(f"  SYSTEM HEALTH CHECK — {result['timestamp'][:19]}")
    print(f"  Overall: {overall_icon} {result['overall'].upper()}")
    print(f"{'='*60}\n")

    for check in result["checks"]:
        icon = status_icons.get(check["status"], "?")
        print(f"  {icon} {check['metric']}: {check['detail']}")

    if result["critical_findings"]:
        print(f"\n  {'─'*50}")
        print(f"  Findings that Gemma will report at next session:")
        for f in result["critical_findings"]:
            print(f"    → {f}")

    print()


if __name__ == "__main__":
    import sys
    verbose = "--quiet" not in sys.argv
    result = run_health_check(verbose=verbose)

    # Always update Self-Model when run standalone
    update_self_model_health(result)

    if "--json" in sys.argv:
        print(json.dumps(result, indent=2, ensure_ascii=False))

    sys.exit(0 if result["overall"] == "healthy" else 1)
