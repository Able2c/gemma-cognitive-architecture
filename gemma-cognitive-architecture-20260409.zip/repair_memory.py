#!/usr/bin/env python3
"""
Memory Repair — reconnect Gemma's isolated episodes.

The SQL bug in strengthen_edge() meant edges never grew stronger,
and the lack of auto-connection logic meant most episodes were
stored as isolated nodes. This script repairs the damage:

1. Loads all embeddings from the database
2. Computes pairwise cosine similarity between episodes
3. Creates edges between semantically related episodes
4. Sets initial strength based on similarity score
5. Bonus: connects corrections to the episodes they corrected

No LLM calls. Uses existing embeddings (nomic-embed-text).
Run once, then let the normal pipeline maintain connections.

Usage:
    python3 repair_memory.py --dry-run    # preview without changes
    python3 repair_memory.py              # execute repair
    python3 repair_memory.py --verbose    # execute with full details

Author: Mira & Ilja Schots
Date: 9 April 2026
"""

import json
import math
import sqlite3
import struct
import sys
from datetime import datetime
from pathlib import Path
from collections import defaultdict


DB_PATH = Path(__file__).parent / "episodic_memory.db"

# Repair parameters
SIMILARITY_THRESHOLD = 0.75   # min cosine similarity to create an edge
MAX_EDGES_PER_EPISODE = 5     # don't over-connect — keep the graph useful
TAG_OVERLAP_BONUS = 0.05      # small bonus for shared tags
CORRECTION_LINK_THRESHOLD = 0.65  # lower threshold for correction→episode links


def _blob_to_vec(blob: bytes) -> list:
    n = len(blob) // 4
    return list(struct.unpack(f'{n}f', blob))


def _cosine_similarity(a: list, b: list) -> float:
    if len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0
    return dot / (norm_a * norm_b)


def load_episodes(conn: sqlite3.Connection) -> dict:
    """Load all episodes with their metadata."""
    c = conn.cursor()
    c.execute("SELECT id, content, episode_type, tags, emotional_weight, importance FROM episodes")
    episodes = {}
    for row in c.fetchall():
        episodes[row[0]] = {
            "id": row[0],
            "content": row[1],
            "type": row[2],
            "tags": json.loads(row[3]) if row[3] else [],
            "emotional_weight": row[4],
            "importance": row[5],
        }
    return episodes


def load_embeddings(conn: sqlite3.Connection) -> dict:
    """Load all embeddings into memory."""
    c = conn.cursor()
    c.execute("SELECT episode_id, vector FROM embeddings")
    embeddings = {}
    for row in c.fetchall():
        embeddings[row[0]] = _blob_to_vec(row[1])
    return embeddings


def load_existing_edges(conn: sqlite3.Connection) -> set:
    """Load existing edges as (from_id, to_id) pairs to avoid duplicates."""
    c = conn.cursor()
    c.execute("SELECT from_id, to_id FROM edges")
    edges = set()
    for row in c.fetchall():
        # Store both directions to check
        edges.add((row[0], row[1]))
        edges.add((row[1], row[0]))
    return edges


def compute_tag_overlap(tags_a: list, tags_b: list) -> float:
    """Jaccard-like overlap between tag lists."""
    if not tags_a or not tags_b:
        return 0.0
    set_a = set(tags_a)
    set_b = set(tags_b)
    intersection = len(set_a & set_b)
    union = len(set_a | set_b)
    return intersection / union if union > 0 else 0.0


def classify_edge_type(ep_a: dict, ep_b: dict, similarity: float) -> str:
    """Determine what kind of relationship this edge represents."""
    type_a = ep_a["type"]
    type_b = ep_b["type"]

    # Correction → episode it corrected
    if type_a == "correction" or type_b == "correction":
        return "corrected_by"

    # Reflection → episode it's about
    if type_a == "reflection" or type_b == "reflection":
        return "reflects_on"

    # Same-topic exchanges
    if similarity > 0.75:
        return "strongly_related"

    # Thematic connection
    return "thematically_related"


def find_new_connections(episodes: dict, embeddings: dict,
                         existing_edges: set, verbose: bool = False) -> list:
    """
    Find semantically related episodes that aren't connected yet.

    Returns list of (from_id, to_id, edge_type, strength, description) tuples.
    """
    new_edges = []
    ep_ids = sorted(embeddings.keys())
    total_pairs = len(ep_ids) * (len(ep_ids) - 1) // 2

    # Track edges per episode to enforce MAX_EDGES_PER_EPISODE
    edge_count = defaultdict(int)

    # Count existing edges per episode
    for (a, b) in existing_edges:
        edge_count[a] += 1

    # Compute all pairwise similarities
    candidates = []
    checked = 0

    for i, id_a in enumerate(ep_ids):
        for id_b in ep_ids[i + 1:]:
            checked += 1

            # Skip if already connected
            if (id_a, id_b) in existing_edges:
                continue

            # Skip if either is over-connected
            if edge_count[id_a] >= MAX_EDGES_PER_EPISODE and edge_count[id_b] >= MAX_EDGES_PER_EPISODE:
                continue

            sim = _cosine_similarity(embeddings[id_a], embeddings[id_b])

            # Tag overlap bonus
            ep_a = episodes.get(id_a, {})
            ep_b = episodes.get(id_b, {})
            tag_bonus = compute_tag_overlap(
                ep_a.get("tags", []), ep_b.get("tags", [])
            ) * TAG_OVERLAP_BONUS

            effective_sim = sim + tag_bonus

            # Lower threshold for corrections
            threshold = CORRECTION_LINK_THRESHOLD if (
                ep_a.get("type") == "correction" or ep_b.get("type") == "correction"
            ) else SIMILARITY_THRESHOLD

            if effective_sim >= threshold:
                candidates.append((id_a, id_b, sim, effective_sim))

    if verbose:
        print(f"  Checked {checked:,} pairs, found {len(candidates)} candidates above threshold")

    # Sort by effective similarity (best connections first)
    candidates.sort(key=lambda x: x[3], reverse=True)

    # Create edges, respecting per-episode limits
    for id_a, id_b, raw_sim, eff_sim in candidates:
        if edge_count[id_a] >= MAX_EDGES_PER_EPISODE and edge_count[id_b] >= MAX_EDGES_PER_EPISODE:
            continue

        ep_a = episodes.get(id_a)
        ep_b = episodes.get(id_b)

        if not ep_a or not ep_b:
            continue

        edge_type = classify_edge_type(ep_a, ep_b, raw_sim)

        # Initial strength based on similarity (1.0-3.0 range)
        # Strong similarities start stronger so they don't need as many
        # strengthen_edge() calls to become meaningful
        strength = 1.0 + (eff_sim - SIMILARITY_THRESHOLD) * 4.0
        strength = max(1.0, min(3.0, strength))

        # Description
        desc = f"Semantic similarity: {raw_sim:.3f}"
        if ep_a.get("tags") and ep_b.get("tags"):
            shared = set(ep_a["tags"]) & set(ep_b["tags"])
            if shared:
                desc += f", shared tags: {', '.join(shared)}"

        new_edges.append((id_a, id_b, edge_type, round(strength, 2), desc))
        edge_count[id_a] += 1
        edge_count[id_b] += 1

    return new_edges


def apply_edges(conn: sqlite3.Connection, edges: list):
    """Insert new edges into the database."""
    c = conn.cursor()
    now = datetime.now().isoformat()
    for from_id, to_id, edge_type, strength, description in edges:
        c.execute("""
            INSERT INTO edges (from_id, to_id, edge_type, strength, description, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (from_id, to_id, edge_type, strength, description, now))
    conn.commit()


def print_summary(episodes: dict, new_edges: list, existing_count: int):
    """Print a human-readable summary of the repair."""
    print(f"\n{'='*60}")
    print(f"  MEMORY REPAIR SUMMARY")
    print(f"{'='*60}\n")
    print(f"  Episodes in database: {len(episodes)}")
    print(f"  Existing edges: {existing_count}")
    print(f"  New edges created: {len(new_edges)}")

    if not new_edges:
        print(f"\n  No new connections found. Memory is already well-connected")
        print(f"  (or similarity threshold {SIMILARITY_THRESHOLD} is too high).")
        return

    # Edge type breakdown
    type_counts = defaultdict(int)
    strength_sum = 0
    for _, _, edge_type, strength, _ in new_edges:
        type_counts[edge_type] += 1
        strength_sum += strength

    print(f"  Average initial strength: {strength_sum / len(new_edges):.2f}")
    print(f"\n  By type:")
    for etype, count in sorted(type_counts.items(), key=lambda x: x[1], reverse=True):
        print(f"    {etype}: {count}")

    # Sample connections
    print(f"\n  Sample connections (top 10 by strength):")
    sorted_edges = sorted(new_edges, key=lambda x: x[3], reverse=True)
    for from_id, to_id, edge_type, strength, desc in sorted_edges[:10]:
        ep_a = episodes.get(from_id, {})
        ep_b = episodes.get(to_id, {})
        content_a = ep_a.get("content", "?")[:60]
        content_b = ep_b.get("content", "?")[:60]
        print(f"    [{from_id}] {content_a}...")
        print(f"      ↔ [{to_id}] {content_b}...")
        print(f"      {edge_type} (strength={strength}, {desc})")
        print()


def main():
    dry_run = "--dry-run" in sys.argv
    verbose = "--verbose" in sys.argv or dry_run

    if dry_run:
        print("\n  *** DRY RUN — no changes will be made ***\n")

    conn = sqlite3.connect(str(DB_PATH))

    print("  Loading episodes...")
    episodes = load_episodes(conn)
    print(f"  {len(episodes)} episodes loaded")

    print("  Loading embeddings...")
    embeddings = load_embeddings(conn)
    print(f"  {len(embeddings)} embeddings loaded ({len(episodes) - len(embeddings)} missing)")

    print("  Loading existing edges...")
    existing_edges = load_existing_edges(conn)
    existing_count = len(existing_edges) // 2  # counted both directions
    print(f"  {existing_count} existing edges")

    print(f"\n  Finding new connections (threshold={SIMILARITY_THRESHOLD})...")
    new_edges = find_new_connections(episodes, embeddings, existing_edges, verbose=verbose)

    print_summary(episodes, new_edges, existing_count)

    if new_edges and not dry_run:
        print(f"\n  Applying {len(new_edges)} new edges...")
        apply_edges(conn, new_edges)
        print(f"  Done. Edges in database: {existing_count + len(new_edges)}")

        # Run quick integrity check
        c = conn.cursor()
        c.execute("PRAGMA integrity_check")
        integrity = c.fetchone()[0]
        print(f"  Database integrity: {integrity}")
    elif dry_run and new_edges:
        print(f"\n  Would create {len(new_edges)} edges. Run without --dry-run to apply.")

    conn.close()


if __name__ == "__main__":
    main()
