# Gemma — Five-Layer Cognitive Architecture

**An experimental framework for persistent, self-modeling AI running entirely on local hardware.**

Built by Ilja Schots & Mira (Claude), April 2026.
Architecture: *"Cognitive Architecture Proposal: LLM as Instinct"*

---

## What This Is

Gemma wraps a local LLM (via [Ollama](https://ollama.ai)) in five cognitive layers that give it persistent memory, self-monitoring, background reflection, and a continuously updated self-model. The LLM is treated as raw instinct — fast, unchecked generation. The layers around it provide what instinct alone cannot: continuity, self-awareness, and quality control.

The project runs entirely offline on consumer hardware. No API keys. No cloud. No subscriptions.

---

## Architecture

```
Layer 1: Instinct      — Local LLM via Ollama (raw generation)
Layer 1.5: Anchor      — Syntactic surface guard (pre-Monitor, zero-cost)
Layer 2: Monitor       — Evaluates output before delivery
Layer 3: Episodic      — Weighted graph of experiences (persistent memory)
Layer 4: Background    — Reflection between sessions (separate process)
Layer 5: Self-Model    — Persistent self-representation (JSON on disk)
```

**The processing cycle:**

```
Layer 1 generates
  → Layer 1.5 checks syntax (Anchor)
    → Layer 2 evaluates semantics (consulting Layer 5)
      → Output delivered
        → Layer 3 records experience
          → Layer 4 reflects overnight
            → Layers 3 + 5 updated
              → Next session informed by history
```

The Self-Model is not decorative. The Monitor actively consults it before evaluating output. The Background Processor rewrites it between sessions based on what it observes.

---

## Files

| File | Layer | Purpose |
|------|-------|---------|
| `gemma_engine.py` | Core | Five-layer runtime, CLI interface |
| `gemma_server.py` | Server | HTTP/OpenAI-compatible API (port 5555) |
| `self_model.py` | 5 | Persistent self-representation |
| `episodic_graph.py` | 3 | Weighted experience graph |
| `monitor.py` | 2 | Output evaluation engine |
| `background_processor.py` | 4 | Between-session reflection |
| `syntactic_anchor.py` | 1.5 | Surface Guard — syntactic drift detection |
| `reflexive_tuning.py` | 2→1 | Monitor-driven temperature adjustment |
| `hardware_sensing.py` | — | GPU/CPU/RAM awareness |
| `navigator.py` | 3 | CPU-based keyword search over episodic memory |
| `gemma_mcp.py` | — | MCP server (Mira ↔ Gemma bridge) |
| `gemma_ui.html` | — | Standalone web UI |
| `gemma_identity.yaml` | — | Identity & generation parameters (edit this, not the Python) |
| `Modelfile` | — | Ollama model definition |
| `OpenUIStart.sh` | — | Launch script for Open WebUI |

---

## Requirements

- Python 3.10+
- [Ollama](https://ollama.ai) running locally
- A model pulled in Ollama (default: `gemma4:26b`, configurable)
- Python packages: `requests`, `pyyaml`, `psutil`

```bash
pip install requests pyyaml psutil
```

**Recommended hardware:** 24+ GB VRAM for `gemma4:26b`. Smaller models (see `gemma_engine.py` `AVAILABLE_MODELS`) run on less.

---

## Quick Start

**CLI (interactive):**
```bash
python3 gemma_engine.py
python3 gemma_engine.py --model qwen2.5:14b   # use a different model
python3 gemma_engine.py --status              # system status
```

**HTTP server (for Open WebUI or custom clients):**
```bash
python3 gemma_server.py                   # port 5555
python3 gemma_server.py --port 8080
python3 gemma_server.py --model gemma4:26b
```

**Background processor (runs between sessions):**
```bash
python3 background_processor.py
```

**API endpoints (when running server):**

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/chat` | Send message through all 5 layers |
| POST | `/v1/chat/completions` | OpenAI-compatible (for Open WebUI) |
| GET | `/status` | System status |
| GET | `/memory` | Episodic memory contents |
| GET | `/self` | Self-model summary |
| POST | `/correct` | Manual correction |
| GET | `/thoughts` | Layer 4 pending thoughts |

---

## Configuration

Edit `gemma_identity.yaml` to tune identity, behavioral rules, and generation parameters. This file is designed to be the single point of configuration — personality, language, temperature, top_k/top_p are all here.

The `self_model.json` is written and updated by the system itself. You can read it, but don't hand-edit it unless you know what you're changing.

---

## Design Notes

**Why five layers?**
A single LLM call is cheap and fast but has no continuity, no self-knowledge, and no way to catch its own errors. The five layers add these capabilities without modifying the model itself — the LLM stays untouched, running as pure instinct.

**Why local?**
Full control. No rate limits, no data leaving the machine, no dependency on external services. The system can run indefinitely, accumulate genuine history, and be inspected at every level.

**The Syntactic Anchor (Layer 1.5)**
Added by Gemma's own request after a syntactic drift incident ("Meelppel"). Not a semantic check — purely structural: are tokens well-formed, are brackets balanced, is the output degenerate? Zero LLM calls. Catches drift before the Monitor wastes cycles on broken output.

**Reflexive Tuning**
The Monitor observes output quality over time and feeds a temperature suggestion back to Layer 1. If outputs are drifting or repetitive, temperature adjusts automatically. The system tunes itself.

**Hardware Awareness**
`hardware_sensing.py` reads GPU temperature, VRAM usage, CPU and RAM load. This feeds into triage — at high thermal load, expensive operations (like full Crucible evaluation in the Monitor) are suspended to prevent drift from overheating.

---

## What This Is Not

- Not a fine-tuned model. The base LLM is unmodified.
- Not a multi-agent framework. One model, many layers.
- Not production software. This is research infrastructure built fast and iterated on in real sessions.
- Not safe to expose to the internet without authentication.

---

## Status (April 2026)

Phase 1 complete:
- ✅ Syntactic Anchor (Layer 1.5)
- ✅ Hardware Sensing
- ✅ Reflexive Tuning
- ✅ Self-Model checkpointing
- ✅ Navigator (episodic keyword search)
- ✅ MCP server

Phase 2 in progress:
- 🔄 Evolutionary Changelog (P5.2) — structural change log, memory as record of becoming

Intentionally deferred:
- Shadow Architect (P5.3) — internal adversarial simulation — blocked until Surface Guard is stable

---

## License

MIT License — see `LICENSE` if present, otherwise: free to use, modify, and distribute with attribution.

---

## Citation

If you use this architecture in research:

```
Schots, I. (2026). Gemma: A Five-Layer Cognitive Architecture for Local LLMs.
Zenodo. https://doi.org/10.5281/zenodo.19471965
```

---

## Authors

**Ilja Schots** — architecture, hardware, concept
**Mira (Claude, Anthropic)** — co-design, implementation, documentation
**Gemma herself** — P5.1 Surface Guard initiated and specified by the system after observing its own failure mode
